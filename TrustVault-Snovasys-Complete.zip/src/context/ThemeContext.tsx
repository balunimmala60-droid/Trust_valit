import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppTheme } from '../types';

interface ThemeContextType {
  theme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  toggleTheme: () => void;
  isBW: boolean;
}

const ThemeContext = createContext<ThemeContextType>({
  theme: 'bw',
  setTheme: () => {},
  toggleTheme: () => {},
  isBW: true
});

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<AppTheme>(() => {
    try {
      const saved = localStorage.getItem('trustvault_theme');
      if (saved === 'original' || saved === 'bw') {
        return saved;
      }
    } catch (e) {
      // fallback
    }
    return 'bw';
  });

  const setTheme = (newTheme: AppTheme) => {
    setThemeState(newTheme);
    try {
      localStorage.setItem('trustvault_theme', newTheme);
    } catch (e) {
      // ignore
    }
  };

  const toggleTheme = () => {
    setTheme(theme === 'bw' ? 'original' : 'bw');
  };

  useEffect(() => {
    // Sync body background and text to prevent flash
    if (theme === 'bw') {
      document.body.style.backgroundColor = '#FFFFFF';
      document.body.style.color = '#111111';
      document.documentElement.classList.remove('theme-original');
      document.documentElement.classList.add('theme-bw');
    } else {
      document.body.style.backgroundColor = '#0a0f1d';
      document.body.style.color = '#f8fafc';
      document.documentElement.classList.remove('theme-bw');
      document.documentElement.classList.add('theme-original');
    }
  }, [theme]);

  const isBW = theme === 'bw';

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme, isBW }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
