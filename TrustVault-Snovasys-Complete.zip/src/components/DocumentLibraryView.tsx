import React, { useState } from 'react';
import { User, VaultDocument, DocumentPermission } from '../types';
import { PermissionDecisionEngine } from '../services/permissionEngine';
import { formatBytes } from '../services/crypto';
import {
  FileText,
  Search,
  Filter,
  Lock,
  Unlock,
  ShieldCheck,
  Download,
  Eye,
  Plus,
  KeyRound
} from 'lucide-react';

interface DocumentLibraryViewProps {
  currentUser: User;
  documents: VaultDocument[];
  permissions: DocumentPermission[];
  onOpenUpload: () => void;
  onSelectDocument: (doc: VaultDocument) => void;
  onPreviewDocument: (doc: VaultDocument) => void;
  onDownloadDocument: (doc: VaultDocument) => void;
  onRequestAccess: (doc: VaultDocument) => void;
}

export const DocumentLibraryView: React.FC<DocumentLibraryViewProps> = ({
  currentUser,
  documents,
  permissions,
  onOpenUpload,
  onSelectDocument,
  onPreviewDocument,
  onDownloadDocument,
  onRequestAccess
}) => {
  const [filterTab, setFilterTab] = useState<'all' | 'owned' | 'shared'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');

  const getPermissionForDoc = (doc: VaultDocument): DocumentPermission | undefined => {
    return permissions.find(p => p.documentId === doc.id && p.userId === currentUser.id);
  };

  const accessibleDocuments = documents.filter(doc => {
    const isOwner = doc.ownerId === currentUser.id;
    const perm = getPermissionForDoc(doc);
    const isAdmin = currentUser.role === 'ADMIN';

    if (filterTab === 'owned') return isOwner;
    if (filterTab === 'shared') return !isOwner && !!perm;
    if (isAdmin) return true;
    return isOwner || !!perm;
  });

  const filteredDocuments = accessibleDocuments.filter(doc => {
    const matchesSearch =
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = categoryFilter === 'All' || doc.category === categoryFilter;

    return matchesSearch && matchesCategory;
  });

  const categories = ['All', 'Financial', 'Legal', 'Technical', 'Security', 'General'];

  return (
    <div className="space-y-6">
      {/* Header with Title & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-black text-[#111111] flex items-center space-x-2">
            <FileText className="w-5 h-5 text-neutral-800" />
            <span>Document Repository & Security Passports</span>
          </h1>
          <p className="text-xs text-neutral-600 mt-1">
            Zero-trust storage with SHA-256 integrity fingerprints, access control boundaries, and versioning.
          </p>
        </div>

        {currentUser.role === 'OWNER' && (
          <button
            onClick={onOpenUpload}
            className="px-4 py-2.5 rounded-lg bg-[#111111] hover:bg-neutral-800 text-white font-semibold text-xs shadow-sm transition-all flex items-center space-x-2 self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Upload New Document</span>
          </button>
        )}
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-[#E5E5E5] shadow-sm">
        <div className="flex items-center space-x-2">
          {[
            { id: 'all', label: 'All Accessible' },
            { id: 'owned', label: 'My Documents' },
            { id: 'shared', label: 'Shared With Me' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilterTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                filterTab === tab.id
                  ? 'bg-[#111111] text-white shadow-sm'
                  : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Category Dropdown */}
          <div className="flex items-center space-x-1.5 bg-[#F8F8F8] px-3 py-1.5 rounded-lg border border-neutral-300 text-xs text-neutral-800">
            <Filter className="w-3.5 h-3.5 text-neutral-500" />
            <select
              value={categoryFilter}
              onChange={e => setCategoryFilter(e.target.value)}
              className="bg-transparent border-none text-neutral-900 focus:outline-none text-xs font-medium"
            >
              {categories.map(c => (
                <option key={c} value={c} className="bg-white text-neutral-900">
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Search Input */}
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search title, tags, description..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-[#F8F8F8] border border-neutral-300 rounded-lg text-xs text-neutral-900 placeholder-neutral-500 focus:outline-none focus:border-neutral-900 focus:bg-white"
            />
          </div>
        </div>
      </div>

      {/* Document Grid */}
      {filteredDocuments.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-[#E5E5E5] shadow-sm">
          <FileText className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-neutral-800">No Documents Found</h3>
          <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
            Zero-trust access policy strictly confines visibility to documents you own or that have been explicitly delegated to your identity.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredDocuments.map(doc => {
            const isOwner = doc.ownerId === currentUser.id;
            const perm = getPermissionForDoc(doc);
            const canRead = PermissionDecisionEngine.evaluate(currentUser, doc, 'READ', perm).allowed;
            const isRevoked = perm?.status === 'REVOKED';

            return (
              <div
                key={doc.id}
                className="bg-white border border-[#E5E5E5] hover:border-neutral-400 rounded-2xl p-5 shadow-sm flex flex-col justify-between transition-all hover:shadow-md group"
              >
                <div>
                  {/* Category & Status Badges */}
                  <div className="flex items-center justify-between mb-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-100 text-neutral-800 border border-neutral-200 uppercase tracking-wider font-mono">
                      {doc.category}
                    </span>

                    <div>
                      {isOwner ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#111111] text-white">
                          OWNER
                        </span>
                      ) : isRevoked ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200 flex items-center space-x-1">
                          <Unlock className="w-3 h-3" />
                          <span>REVOKED</span>
                        </span>
                      ) : perm ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center space-x-1">
                          <Lock className="w-3 h-3" />
                          <span>{perm.permissionLevel} GRANTED</span>
                        </span>
                      ) : currentUser.role === 'ADMIN' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-100 text-neutral-700 border border-neutral-300">
                          ADMIN (AUDIT ONLY)
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-100 text-neutral-500">
                          UNSHARED
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Document Title & Description */}
                  <h3
                    onClick={() => onSelectDocument(doc)}
                    className="text-sm font-bold text-neutral-900 group-hover:underline transition-colors cursor-pointer line-clamp-1"
                    title={doc.title}
                  >
                    {doc.title}
                  </h3>
                  <p className="text-xs text-neutral-600 mt-1 line-clamp-2 min-h-[32px]">
                    {doc.description || 'No description provided.'}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1 mt-3">
                    {doc.tags.map(t => (
                      <span key={t} className="text-[10px] text-neutral-600 bg-neutral-50 px-2 py-0.5 rounded border border-neutral-200">
                        #{t}
                      </span>
                    ))}
                  </div>

                  {/* Document Integrity & Metadata */}
                  <div className="mt-4 pt-3 border-t border-neutral-100 space-y-1.5 text-[11px] text-neutral-600 font-mono">
                    <div className="flex items-center justify-between">
                      <span className="text-neutral-400">SHA-256 Hash:</span>
                      <span className="text-neutral-900 font-mono font-medium" title={doc.integrityHash}>
                        {doc.integrityHash.substring(0, 12)}...
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-neutral-400">Size & Ver:</span>
                      <span className="text-neutral-700">{formatBytes(doc.sizeBytes)} • v{doc.currentVersion}</span>
                    </div>

                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-neutral-400">Owner:</span>
                      <span className="text-neutral-800 font-sans font-medium truncate max-w-[140px]">{doc.ownerName}</span>
                    </div>
                  </div>
                </div>

                {/* Bottom Action Buttons */}
                <div className="mt-5 pt-3 border-t border-neutral-100 flex items-center justify-between gap-2">
                  <button
                    onClick={() => onSelectDocument(doc)}
                    className="flex-1 py-1.5 px-2 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-900 text-xs font-semibold transition-all flex items-center justify-center space-x-1"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-neutral-700" />
                    <span>Passport</span>
                  </button>

                  {canRead ? (
                    <>
                      <button
                        onClick={() => onPreviewDocument(doc)}
                        className="py-1.5 px-2.5 rounded-lg bg-white hover:bg-neutral-50 border border-neutral-300 text-neutral-900 text-xs font-semibold transition-all flex items-center space-x-1 shadow-sm"
                        title="Secure Watermarked Preview"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Preview</span>
                      </button>

                      <button
                        onClick={() => onDownloadDocument(doc)}
                        className="py-1.5 px-2.5 rounded-lg bg-[#111111] hover:bg-neutral-800 text-white text-xs font-semibold transition-all flex items-center space-x-1 shadow-sm"
                        title="Authorized Download"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Download</span>
                      </button>
                    </>
                  ) : isRevoked ? (
                    <button
                      onClick={() => onDownloadDocument(doc)}
                      className="py-1.5 px-2.5 rounded-lg bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-semibold transition-all flex items-center space-x-1"
                      title="Attempt Download to Verify Revocation Rejection"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Test Revocation</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => onRequestAccess(doc)}
                      className="py-1.5 px-2.5 rounded-lg bg-white hover:bg-neutral-50 border border-neutral-300 text-neutral-900 text-xs font-semibold transition-all flex items-center space-x-1 shadow-sm"
                    >
                      <KeyRound className="w-3.5 h-3.5" />
                      <span>Request Access</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
