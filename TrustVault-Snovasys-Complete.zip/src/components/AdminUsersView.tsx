import React from 'react';
import { User } from '../types';
import {
  Shield,
  UserX,
  Lock,
  CheckCircle
} from 'lucide-react';

interface AdminUsersViewProps {
  currentUser: User;
  allUsers: User[];
  onToggleUserStatus: (userId: string) => void;
}

export const AdminUsersView: React.FC<AdminUsersViewProps> = ({
  currentUser,
  allUsers,
  onToggleUserStatus
}) => {
  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-white border border-[#E5E5E5] shadow-sm">
        <div className="flex items-center space-x-2 text-xs font-bold text-neutral-900 uppercase tracking-wider mb-1.5">
          <Shield className="w-4 h-4 text-neutral-800" />
          <span>System Administration & Identity Governance</span>
        </div>
        <h1 className="text-2xl font-black text-[#111111] tracking-tight">
          User Directory & Tenant Access Management
        </h1>
        <p className="text-sm text-neutral-600 mt-1 max-w-2xl leading-relaxed">
          Administrators control user provisioning, lifecycle state, and system auditing. In accordance with TrustVault zero-trust separation of duties, administrative accounts do not inherit blanket read access to tenant document contents.
        </p>
      </div>

      {/* Zero-Trust Notice */}
      <div className="p-4 rounded-xl bg-[#F8F8F8] border border-neutral-300 text-xs text-neutral-800 flex items-start space-x-3">
        <Lock className="w-4 h-4 text-neutral-900 shrink-0 mt-0.5" />
        <div>
          <div className="font-bold text-neutral-900">Administrative Privilege Boundary:</div>
          <p className="text-neutral-600 mt-0.5">
            The ADMIN role has authority to suspend accounts, monitor system health, and inspect audit logs. Attempting to view confidential document files triggers an intentional 403 Forbidden denial unless an owner has explicitly granted permission.
          </p>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white border border-[#E5E5E5] rounded-2xl overflow-hidden shadow-sm">
        <div className="p-4 border-b border-neutral-200 flex items-center justify-between">
          <span className="text-xs font-bold text-neutral-900 uppercase tracking-wider">
            Registered Identities ({allUsers.length})
          </span>
          <span className="text-[10px] text-neutral-500 font-mono">
            Click status toggle to test suspension behavior in real time
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F8F8F8] text-neutral-600 uppercase text-[10px] font-bold tracking-wider border-b border-neutral-200">
              <tr>
                <th className="p-4">User</th>
                <th className="p-4">Role</th>
                <th className="p-4">Account Status</th>
                <th className="p-4">Created</th>
                <th className="p-4">Last Login</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 text-neutral-800">
              {allUsers.map(u => (
                <tr key={u.id} className="hover:bg-neutral-50 transition-colors">
                  <td className="p-4">
                    <div className="font-bold text-neutral-900">{u.fullName}</div>
                    <div className="text-[11px] text-neutral-500 font-mono">{u.email}</div>
                  </td>

                  <td className="p-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-neutral-900 text-white">
                      {u.role}
                    </span>
                  </td>

                  <td className="p-4">
                    <span className={`px-2.5 py-1 rounded text-[10px] font-bold inline-flex items-center space-x-1 ${
                      u.accountStatus === 'ACTIVE'
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        : 'bg-rose-50 text-rose-800 border border-rose-200'
                    }`}>
                      {u.accountStatus === 'ACTIVE' ? (
                        <CheckCircle className="w-3 h-3 text-emerald-700" />
                      ) : (
                        <UserX className="w-3 h-3 text-rose-700" />
                      )}
                      <span>{u.accountStatus}</span>
                    </span>
                  </td>

                  <td className="p-4 text-neutral-500 font-mono">
                    {new Date(u.createdAt).toLocaleDateString()}
                  </td>

                  <td className="p-4 text-neutral-500 font-mono">
                    {u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleTimeString() : 'Never'}
                  </td>

                  <td className="p-4 text-right">
                    {u.id !== currentUser.id ? (
                      <button
                        onClick={() => onToggleUserStatus(u.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                          u.accountStatus === 'ACTIVE'
                            ? 'bg-white hover:bg-rose-50 border border-rose-300 text-rose-700'
                            : 'bg-white hover:bg-emerald-50 border border-emerald-300 text-emerald-800'
                        }`}
                      >
                        {u.accountStatus === 'ACTIVE' ? 'Suspend Account' : 'Activate Account'}
                      </button>
                    ) : (
                      <span className="text-[10px] text-neutral-400 italic">Self (Active)</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
