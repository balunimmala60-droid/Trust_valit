import React from 'react';
import { User, VaultDocument, DocumentPermission, AuditRecord } from '../types';
import {
  ShieldCheck,
  ShieldAlert,
  FileText,
  Lock,
  Unlock,
  Users,
  Activity,
  ArrowRight,
  AlertTriangle,
  CheckCircle,
  Database,
  Plus
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

interface DashboardViewProps {
  currentUser: User;
  allUsers: User[];
  documents: VaultDocument[];
  permissions: DocumentPermission[];
  auditEvents: AuditRecord[];
  onSelectTab: (tab: string) => void;
  onSwitchUser: (user: User) => void;
  onOpenUpload: () => void;
  chainValid: boolean;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  currentUser,
  allUsers,
  documents,
  permissions,
  auditEvents,
  onSelectTab,
  onSwitchUser,
  onOpenUpload,
  chainValid
}) => {
  const activePermissions = permissions.filter(p => p.status === 'ACTIVE');
  const revokedPermissions = permissions.filter(p => p.status === 'REVOKED');
  const deniedAttempts = auditEvents.filter(e => e.decision === 'DENY');

  // Chart data: Allowed vs Denied by common actions
  const chartData = [
    { name: 'Reads', allowed: auditEvents.filter(e => e.action === 'READ' && e.decision === 'ALLOW').length, denied: auditEvents.filter(e => e.action === 'READ' && e.decision === 'DENY').length },
    { name: 'Downloads', allowed: auditEvents.filter(e => e.action === 'DOWNLOAD' && e.decision === 'ALLOW').length, denied: auditEvents.filter(e => e.action === 'DOWNLOAD' && e.decision === 'DENY').length },
    { name: 'Uploads', allowed: auditEvents.filter(e => e.action === 'UPLOAD' && e.decision === 'ALLOW').length, denied: auditEvents.filter(e => e.action === 'UPLOAD' && e.decision === 'DENY').length },
    { name: 'Grants', allowed: auditEvents.filter(e => e.action === 'GRANT_PERMISSION' && e.decision === 'ALLOW').length, denied: auditEvents.filter(e => e.action === 'GRANT_PERMISSION' && e.decision === 'DENY').length },
    { name: 'Attacks', allowed: 0, denied: auditEvents.filter(e => e.action === 'ATTACK_SIMULATION').length }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner: Black-and-White Cybersecurity Overview */}
      <div className="p-6 rounded-2xl bg-white border border-[#E5E5E5] shadow-sm relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 text-xs font-bold text-neutral-900 uppercase tracking-wider mb-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
              <span>Zero-Trust Security Perimeter Active</span>
            </div>
            <h1 className="text-2xl font-black text-[#111111] tracking-tight">
              Welcome back, {currentUser.fullName}
            </h1>
            <p className="text-sm text-neutral-600 mt-1 max-w-2xl leading-relaxed">
              Operating as <span className="font-mono font-semibold text-neutral-900 bg-neutral-100 px-1.5 py-0.5 rounded border border-neutral-200">{currentUser.email}</span> with role <span className="font-mono font-bold text-neutral-900 uppercase bg-neutral-100 px-1.5 py-0.5 rounded border border-neutral-200">{currentUser.role}</span>. All operations pass through the Centralized Decision Engine and are cryptographically chained to the SHA-256 audit ledger.
            </p>
          </div>

          <div className="flex items-center space-x-2.5">
            {currentUser.role === 'OWNER' && (
              <button
                onClick={onOpenUpload}
                className="px-4 py-2.5 rounded-lg bg-[#111111] hover:bg-neutral-800 text-white font-semibold text-xs shadow-sm transition-all flex items-center space-x-2"
              >
                <Plus className="w-4 h-4" />
                <span>Upload Document</span>
              </button>
            )}

            <button
              onClick={() => onSelectTab('attack-lab')}
              className="px-4 py-2.5 rounded-lg bg-white hover:bg-neutral-50 border border-neutral-300 text-neutral-900 font-semibold text-xs transition-all flex items-center space-x-2 shadow-sm"
            >
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>Simulate Attacks</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row: Crisp White Cards with #E5E5E5 Borders */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="p-4 rounded-xl bg-white border border-[#E5E5E5] shadow-sm hover:border-neutral-400 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs text-neutral-500 font-semibold uppercase tracking-wider">Documents</span>
            <FileText className="w-4 h-4 text-neutral-700" />
          </div>
          <div className="text-2xl font-black text-neutral-900 mt-2">{documents.length}</div>
          <div className="text-[11px] text-neutral-500 mt-1">Private storage blobs</div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E5E5E5] shadow-sm hover:border-neutral-400 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs text-neutral-500 font-semibold uppercase tracking-wider">Audit Blocks</span>
            <Database className="w-4 h-4 text-neutral-700" />
          </div>
          <div className="text-2xl font-black text-neutral-900 mt-2">{auditEvents.length}</div>
          <div className="flex items-center space-x-1.5 text-[11px] mt-1 font-medium">
            <span className={`w-2 h-2 rounded-full ${chainValid ? 'bg-emerald-600' : 'bg-rose-600 animate-ping'}`} />
            <span className={chainValid ? 'text-emerald-700' : 'text-rose-600'}>
              {chainValid ? 'Chain Valid (SHA-256)' : 'Tamper Detected!'}
            </span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E5E5E5] shadow-sm hover:border-neutral-400 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs text-neutral-500 font-semibold uppercase tracking-wider">Active Grants</span>
            <Lock className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-neutral-900 mt-2">{activePermissions.length}</div>
          <div className="text-[11px] text-emerald-700 font-medium mt-1">READ & EDIT Delegations</div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E5E5E5] shadow-sm hover:border-neutral-400 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs text-neutral-500 font-semibold uppercase tracking-wider">Revoked Access</span>
            <Unlock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-neutral-900 mt-2">{revokedPermissions.length}</div>
          <div className="text-[11px] text-amber-700 font-medium mt-1">0ms Cutoff Enforced</div>
        </div>

        <div className="p-4 rounded-xl bg-white border border-[#E5E5E5] shadow-sm hover:border-neutral-400 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs text-neutral-500 font-semibold uppercase tracking-wider">Blocked Attempts</span>
            <ShieldAlert className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-black text-rose-600 mt-2">{deniedAttempts.length}</div>
          <div className="text-[11px] text-neutral-500 mt-1">Zero-trust denials logged</div>
        </div>
      </div>

      {/* Two Column Layout: Live Access Radar & Security Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Live Access Radar */}
        <div className="lg:col-span-7 bg-white border border-[#E5E5E5] rounded-2xl p-5 shadow-sm flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-neutral-200">
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-neutral-900" />
              <h2 className="text-xs font-bold text-neutral-900 uppercase tracking-wider">Live Access Radar</h2>
            </div>
            <button
              onClick={() => onSelectTab('audit-trail')}
              className="text-xs font-semibold text-neutral-900 hover:underline flex items-center space-x-1"
            >
              <span>View Full Ledger</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <p className="text-xs text-neutral-600 mt-2">
            Real-time server-evaluated access decisions. Denied events are forensically recorded alongside authorized requests.
          </p>

          <div className="mt-4 space-y-2 flex-1 overflow-y-auto max-h-[340px] pr-1">
            {auditEvents.slice(-6).reverse().map(evt => (
              <div
                key={evt.eventId}
                className={`p-3 rounded-xl border text-xs transition-all flex items-start justify-between ${
                  evt.decision === 'ALLOW'
                    ? 'bg-neutral-50/70 border-neutral-200 hover:border-neutral-300'
                    : 'bg-rose-50/80 border-rose-200 hover:border-rose-300'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase ${
                        evt.decision === 'ALLOW'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-rose-100 text-rose-800 border border-rose-300'
                      }`}
                    >
                      {evt.decision}
                    </span>
                    <span className="font-bold text-neutral-900">{evt.action}</span>
                    {evt.documentTitle && (
                      <span className="text-neutral-600 truncate max-w-[220px]" title={evt.documentTitle}>
                        • {evt.documentTitle}
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-neutral-600">
                    Actor: <span className="text-neutral-900 font-mono font-medium">{evt.actorEmail}</span> ({evt.actorRole})
                  </div>
                  <div className="text-[11px] text-neutral-500 italic">
                    Reason: {evt.reason}
                  </div>
                </div>

                <div className="text-right text-[10px] text-neutral-500 shrink-0">
                  <div>{new Date(evt.timestamp).toLocaleTimeString()}</div>
                  <div className="font-mono text-neutral-400 mt-1">H: {evt.currentHash.substring(0, 8)}...</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Persona Switcher & Decisions Chart */}
        <div className="lg:col-span-5 space-y-6">
          {/* Quick Persona Card for Hackathon Evaluator */}
          <div className="bg-white border border-[#E5E5E5] rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-neutral-900 uppercase tracking-wider flex items-center space-x-1.5">
                <Users className="w-4 h-4 text-neutral-700" />
                <span>Judge Persona Switcher</span>
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-neutral-100 text-neutral-800 border border-neutral-200 font-mono font-semibold">
                1-Click Testing
              </span>
            </div>

            <p className="text-xs text-neutral-600 mb-3">
              Switch roles instantly to verify security boundaries:
            </p>

            <div className="space-y-2">
              {allUsers.map(user => (
                <button
                  key={user.id}
                  onClick={() => onSwitchUser(user)}
                  className={`w-full p-2.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between ${
                    currentUser.id === user.id
                      ? 'bg-neutral-100 border-neutral-900 text-neutral-900 shadow-sm font-semibold'
                      : 'bg-white border-neutral-200 hover:border-neutral-300 text-neutral-700 hover:bg-neutral-50'
                  }`}
                >
                  <div>
                    <div className="font-bold flex items-center space-x-1.5">
                      <span>{user.fullName}</span>
                      {currentUser.id === user.id && (
                        <CheckCircle className="w-3.5 h-3.5 text-neutral-900" />
                      )}
                    </div>
                    <div className="text-[10px] text-neutral-500 font-mono mt-0.5">{user.email}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-neutral-900 text-white">
                    {user.role}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Decision Chart in B&W */}
          <div className="bg-white border border-[#E5E5E5] rounded-2xl p-5 shadow-sm">
            <h3 className="text-xs font-bold text-neutral-900 uppercase tracking-wider mb-2">
              Security Decisions Breakdown
            </h3>
            <div className="h-40 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis dataKey="name" stroke="#6B7280" fontSize={10} />
                  <YAxis stroke="#6B7280" fontSize={10} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#111111', borderColor: '#333333', color: '#FFFFFF', borderRadius: '8px', fontSize: '11px' }}
                  />
                  <Bar dataKey="allowed" fill="#111111" name="Allowed" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="denied" fill="#DC2626" name="Denied" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
