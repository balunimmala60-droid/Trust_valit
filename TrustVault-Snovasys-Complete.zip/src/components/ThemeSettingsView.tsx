import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { Palette, CheckCircle, Sun, Moon, Sparkles, Shield } from 'lucide-react';

export const ThemeSettingsView: React.FC = () => {
  const { theme, setTheme, isBW } = useTheme();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className={`p-6 rounded-2xl border shadow-sm transition-colors ${
        isBW ? 'bg-white border-[#E5E5E5]' : 'bg-slate-900 border-slate-800'
      }`}>
        <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider mb-1.5">
          <Palette className={`w-4 h-4 ${isBW ? 'text-neutral-800' : 'text-cyan-400'}`} />
          <span className={isBW ? 'text-neutral-900' : 'text-cyan-400'}>Display Theme Settings</span>
        </div>
        <h1 className={`text-2xl font-black tracking-tight ${isBW ? 'text-[#111111]' : 'text-white'}`}>
          Change Application Theme
        </h1>
        <p className={`text-sm mt-1 max-w-2xl leading-relaxed ${isBW ? 'text-neutral-600' : 'text-slate-400'}`}>
          Switch between the high-contrast <strong>Black & White Security</strong> theme and the original <strong>TrustVault Cyber</strong> theme at any time. Your preference persists automatically across browser refreshes.
        </p>
      </div>

      {/* Theme Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Theme A: Black & White Security */}
        <div
          onClick={() => setTheme('bw')}
          className={`p-6 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
            theme === 'bw'
              ? 'border-neutral-900 bg-white shadow-md ring-2 ring-neutral-900/10'
              : isBW
              ? 'border-neutral-200 bg-white hover:border-neutral-400'
              : 'border-slate-800 bg-slate-900 hover:border-slate-700'
          }`}
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-5 h-5 rounded-full bg-black border border-neutral-300" />
                <h3 className={`text-base font-bold ${isBW ? 'text-neutral-900' : 'text-white'}`}>
                  Theme A: Black & White Security
                </h3>
              </div>
              {theme === 'bw' && (
                <span className="px-2.5 py-1 rounded text-[10px] font-bold bg-neutral-900 text-white flex items-center space-x-1">
                  <CheckCircle className="w-3 h-3" />
                  <span>ACTIVE</span>
                </span>
              )}
            </div>

            <p className={`text-xs leading-relaxed ${isBW ? 'text-neutral-600' : 'text-slate-400'}`}>
              Clean, minimalist high-contrast monochrome design built for enterprise compliance, legal reviews, and crisp readability.
            </p>

            {/* Color Swatches */}
            <div className="space-y-2 pt-2">
              <span className={`text-[10px] uppercase font-bold tracking-wider ${isBW ? 'text-neutral-500' : 'text-slate-500'}`}>
                Palette Specifications
              </span>
              <div className="grid grid-cols-4 gap-2 text-center text-[10px] font-mono">
                <div className="p-2 rounded border border-neutral-300 bg-white text-black font-bold">#FFFFFF<br/><span className="text-[9px] font-sans font-normal text-neutral-500">Main BG</span></div>
                <div className="p-2 rounded bg-neutral-900 text-white font-bold">#111111<br/><span className="text-[9px] font-sans font-normal text-neutral-400">Primary</span></div>
                <div className="p-2 rounded border border-neutral-200 bg-[#F8F8F8] text-neutral-800">#F8F8F8<br/><span className="text-[9px] font-sans font-normal text-neutral-500">Secondary</span></div>
                <div className="p-2 rounded border border-neutral-300 bg-white text-neutral-600">#E5E5E5<br/><span className="text-[9px] font-sans font-normal text-neutral-500">Borders</span></div>
              </div>
            </div>

            {/* Component Previews */}
            <div className="p-3 rounded-xl bg-[#F8F8F8] border border-neutral-200 space-y-2">
              <div className="text-[10px] font-bold text-neutral-600 uppercase">Button Styles</div>
              <div className="flex items-center space-x-2">
                <button className="px-3 py-1 bg-black text-white text-xs font-semibold rounded shadow-sm">
                  Primary Button
                </button>
                <button className="px-3 py-1 bg-white border border-neutral-300 text-black text-xs font-semibold rounded">
                  Secondary
                </button>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                  Allow
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-50 text-rose-800 border border-rose-200">
                  Deny
                </span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-neutral-200 mt-4 flex justify-end">
            <button
              onClick={() => setTheme('bw')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                theme === 'bw'
                  ? 'bg-neutral-900 text-white'
                  : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-800'
              }`}
            >
              {theme === 'bw' ? 'Current Active Theme' : 'Apply Black & White'}
            </button>
          </div>
        </div>

        {/* Theme B: Original TrustVault Cyber */}
        <div
          onClick={() => setTheme('original')}
          className={`p-6 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
            theme === 'original'
              ? 'border-cyan-400 bg-slate-900 shadow-md ring-2 ring-cyan-500/20'
              : isBW
              ? 'border-neutral-200 bg-white hover:border-neutral-400'
              : 'border-slate-800 bg-slate-900 hover:border-slate-700'
          }`}
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-5 h-5 rounded-full bg-cyan-400 border border-cyan-200" />
                <h3 className={`text-base font-bold ${isBW ? 'text-neutral-900' : 'text-white'}`}>
                  Theme B: Original TrustVault Theme
                </h3>
              </div>
              {theme === 'original' && (
                <span className="px-2.5 py-1 rounded text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 flex items-center space-x-1">
                  <CheckCircle className="w-3 h-3 text-cyan-400" />
                  <span>ACTIVE</span>
                </span>
              )}
            </div>

            <p className={`text-xs leading-relaxed ${isBW ? 'text-neutral-600' : 'text-slate-400'}`}>
              The signature TrustVault dark cybersecurity interface featuring a deep navy background, electric cyan highlights, and cyber aesthetic.
            </p>

            {/* Color Swatches */}
            <div className="space-y-2 pt-2">
              <span className={`text-[10px] uppercase font-bold tracking-wider ${isBW ? 'text-neutral-500' : 'text-slate-500'}`}>
                Palette Specifications
              </span>
              <div className="grid grid-cols-4 gap-2 text-center text-[10px] font-mono">
                <div className="p-2 rounded border border-slate-700 bg-[#0a0f1d] text-cyan-400 font-bold">#0a0f1d<br/><span className="text-[9px] font-sans font-normal text-slate-400">Navy BG</span></div>
                <div className="p-2 rounded bg-cyan-500 text-slate-950 font-bold">#00f0ff<br/><span className="text-[9px] font-sans font-normal text-slate-900">Cyan</span></div>
                <div className="p-2 rounded border border-slate-700 bg-slate-900 text-slate-200">#0f172a<br/><span className="text-[9px] font-sans font-normal text-slate-400">Card BG</span></div>
                <div className="p-2 rounded border border-slate-600 bg-slate-800 text-slate-300">#1e293b<br/><span className="text-[9px] font-sans font-normal text-slate-400">Borders</span></div>
              </div>
            </div>

            {/* Component Previews */}
            <div className="p-3 rounded-xl bg-[#0a0f1d] border border-slate-800 space-y-2 text-slate-200">
              <div className="text-[10px] font-bold text-cyan-400 uppercase">Button Styles</div>
              <div className="flex items-center space-x-2">
                <button className="px-3 py-1 bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-semibold rounded shadow-sm shadow-cyan-500/20">
                  Primary Button
                </button>
                <button className="px-3 py-1 bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold rounded">
                  Secondary
                </button>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                  Allow
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-800">
                  Deny
                </span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 mt-4 flex justify-end">
            <button
              onClick={() => setTheme('original')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                theme === 'original'
                  ? 'bg-cyan-600 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700'
              }`}
            >
              {theme === 'original' ? 'Current Active Theme' : 'Apply Original Theme'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
