import React, { useState, useRef } from 'react';
import { User, VaultDocument } from '../types';
import { inspectFileMagicBytes, sha256Bytes, formatBytes } from '../services/crypto';
import {
  X,
  Upload,
  FileCheck,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface UploadModalProps {
  currentUser: User;
  onClose: () => void;
  onUploadSuccess: (newDoc: VaultDocument) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  currentUser,
  onClose,
  onUploadSuccess
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileValidation, setFileValidation] = useState<{
    valid: boolean;
    detectedType: string;
    expectedExtension: string;
    error?: string;
  } | null>(null);
  const [fileHash, setFileHash] = useState<string>('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<'Financial' | 'Legal' | 'Technical' | 'Security' | 'General'>('General');
  const [tags, setTags] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (file: File) => {
    setSelectedFile(file);
    setIsProcessing(true);

    try {
      const validation = await inspectFileMagicBytes(file);
      setFileValidation(validation);

      const buffer = await file.arrayBuffer();
      const hash = await sha256Bytes(buffer);
      setFileHash(hash);

      if (!title) {
        const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[_.-]/g, ' ');
        setTitle(cleanName);
      }
    } catch (e) {
      console.error('File inspection failed:', e);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile || !fileValidation?.valid) return;

    const ext = selectedFile.name.split('.').pop()?.toLowerCase() || 'bin';
    const storageId = `enc_blob_${Math.random().toString(36).substring(2, 10)}_${Date.now()}.${ext}`;

    const newDoc: VaultDocument = {
      id: 'doc_vault_' + Math.random().toString(36).substring(2, 9),
      ownerId: currentUser.id,
      ownerName: currentUser.fullName,
      ownerEmail: currentUser.email,
      title: title || selectedFile.name,
      description,
      category,
      tags: tags.split(',').map(t => t.trim()).filter(Boolean),
      originalFilename: selectedFile.name,
      storageIdentifier: storageId,
      mimeType: fileValidation.detectedType,
      sizeBytes: selectedFile.size,
      fileExtension: ext,
      integrityHash: fileHash,
      currentVersion: 1,
      isDeleted: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      contentPreview: `TRUSTVAULT SECURE PAYLOAD: ${title}. Validated byte stream stored at ${storageId}. Original hash: ${fileHash}. Verified by ${currentUser.fullName}.`
    };

    onUploadSuccess(newDoc);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white border border-[#E5E5E5] rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-[#E5E5E5] flex items-center justify-between bg-[#F8F8F8]">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-black text-white flex items-center justify-center shadow-sm">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-neutral-900 tracking-tight">Upload & Inspect Document</h2>
              <p className="text-xs text-neutral-500">Strict signature verification, magic byte checking, and SHA-256 fingerprinting.</p>
            </div>
          </div>

          <button onClick={onClose} className="p-2 rounded-lg text-neutral-400 hover:text-neutral-900 hover:bg-neutral-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 text-xs flex-1 bg-white text-neutral-900">
          {/* File Dropzone */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
              selectedFile
                ? fileValidation?.valid
                  ? 'border-emerald-500 bg-emerald-50/50'
                  : 'border-rose-500 bg-rose-50/50'
                : 'border-neutral-300 hover:border-black bg-[#F8F8F8]'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={e => {
                if (e.target.files?.[0]) handleFileChange(e.target.files[0]);
              }}
              className="hidden"
              accept=".pdf,.docx,.jpg,.jpeg,.png"
            />

            {selectedFile ? (
              <div className="space-y-2">
                <FileCheck className={`w-8 h-8 mx-auto ${fileValidation?.valid ? 'text-emerald-600' : 'text-rose-600'}`} />
                <div className="font-bold text-neutral-900 text-sm">{selectedFile.name}</div>
                <div className="text-neutral-500 text-xs font-mono">{formatBytes(selectedFile.size)}</div>

                {isProcessing ? (
                  <div className="text-neutral-700 font-mono">Inspecting magic bytes & computing SHA-256...</div>
                ) : fileValidation?.valid ? (
                  <div className="flex items-center justify-center space-x-1.5 text-emerald-700 text-xs font-bold">
                    <CheckCircle className="w-4 h-4" />
                    <span>File Signature Verified: {fileValidation.detectedType}</span>
                  </div>
                ) : (
                  <div className="flex items-center justify-center space-x-1.5 text-rose-700 text-xs font-bold">
                    <AlertCircle className="w-4 h-4" />
                    <span>{fileValidation?.error || 'Signature inspection failed!'}</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-2">
                <Upload className="w-8 h-8 text-neutral-700 mx-auto" />
                <div className="font-bold text-neutral-900">Choose or drop document to upload</div>
                <div className="text-neutral-500 text-[11px]">
                  Supported formats: PDF, DOCX, PNG, JPG, JPEG (Max 15MB)
                </div>
              </div>
            )}
          </div>

          {/* Real-time Integrity Hash Display */}
          {fileHash && (
            <div className="p-3 bg-[#F8F8F8] border border-[#E5E5E5] rounded-xl space-y-1">
              <span className="text-[10px] text-neutral-500 uppercase font-bold tracking-wider block">
                Calculated SHA-256 Integrity Checksum
              </span>
              <div className="font-mono text-neutral-900 text-[11px] break-all select-all font-semibold">
                {fileHash}
              </div>
            </div>
          )}

          {/* Form Fields */}
          <div className="space-y-3">
            <div>
              <label className="text-neutral-700 block mb-1 font-semibold">Document Title</label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Q3 Audited Financial Statements"
                className="w-full bg-white border border-neutral-300 rounded-lg p-2.5 text-xs text-neutral-900 focus:outline-none focus:border-black"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-neutral-700 block mb-1 font-semibold">Category</label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value as any)}
                  className="w-full bg-white border border-neutral-300 rounded-lg p-2.5 text-xs text-neutral-900 focus:outline-none focus:border-black font-medium"
                >
                  <option value="Financial">Financial</option>
                  <option value="Legal">Legal</option>
                  <option value="Technical">Technical</option>
                  <option value="Security">Security</option>
                  <option value="General">General</option>
                </select>
              </div>

              <div>
                <label className="text-neutral-700 block mb-1 font-semibold">Tags (comma-separated)</label>
                <input
                  type="text"
                  value={tags}
                  onChange={e => setTags(e.target.value)}
                  placeholder="Audit, Q3, Confidential"
                  className="w-full bg-white border border-neutral-300 rounded-lg p-2.5 text-xs text-neutral-900 focus:outline-none focus:border-black"
                />
              </div>
            </div>

            <div>
              <label className="text-neutral-700 block mb-1 font-semibold">Description</label>
              <textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                rows={3}
                placeholder="Describe the document purpose, classification level, and confidentiality constraints..."
                className="w-full bg-white border border-neutral-300 rounded-lg p-2.5 text-xs text-neutral-900 focus:outline-none focus:border-black"
              />
            </div>
          </div>

          {/* Footer Submit */}
          <div className="pt-3 border-t border-[#E5E5E5] flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-neutral-600 hover:text-black hover:bg-neutral-100"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={!selectedFile || !fileValidation?.valid || isProcessing}
              className="px-5 py-2.5 rounded-lg bg-[#111111] hover:bg-neutral-800 disabled:opacity-40 text-white font-semibold shadow-sm transition-all"
            >
              Confirm & Store in Vault
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
