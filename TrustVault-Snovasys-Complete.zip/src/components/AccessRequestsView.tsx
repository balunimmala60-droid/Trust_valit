import React, { useState } from 'react';
import { User, VaultDocument, AccessRequest, PermissionLevel } from '../types';
import {
  KeyRound,
  CheckCircle,
  XCircle,
  Send,
  X
} from 'lucide-react';

interface AccessRequestsViewProps {
  currentUser: User;
  documents: VaultDocument[];
  accessRequests: AccessRequest[];
  onApproveRequest: (requestId: string, level: PermissionLevel) => void;
  onRejectRequest: (requestId: string, reason: string) => void;
  onCreateRequest: (docId: string, level: PermissionLevel, justification: string) => void;
}

export const AccessRequestsView: React.FC<AccessRequestsViewProps> = ({
  currentUser,
  documents,
  accessRequests,
  onApproveRequest,
  onRejectRequest,
  onCreateRequest
}) => {
  const [showNewRequestModal, setShowNewRequestModal] = useState(false);
  const [selectedDocId, setSelectedDocId] = useState(documents[0]?.id || '');
  const [requestedLevel, setRequestedLevel] = useState<PermissionLevel>('READ');
  const [justification, setJustification] = useState('');

  const isOwner = currentUser.role === 'OWNER';

  const relevantRequests = accessRequests.filter(req => {
    if (currentUser.role === 'ADMIN') return true;
    if (isOwner) return req.ownerId === currentUser.id;
    return req.requesterId === currentUser.id;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDocId || !justification) return;
    onCreateRequest(selectedDocId, requestedLevel, justification);
    setJustification('');
    setShowNewRequestModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-black text-[#111111] flex items-center space-x-2">
            <KeyRound className="w-5 h-5 text-neutral-800" />
            <span>Document Access Delegation Requests</span>
          </h1>
          <p className="text-xs text-neutral-600 mt-1">
            Formal, audited workflow for requesting and approving granular READ/EDIT document privileges.
          </p>
        </div>

        <button
          onClick={() => setShowNewRequestModal(true)}
          className="px-4 py-2.5 rounded-lg bg-[#111111] hover:bg-neutral-800 text-white font-semibold text-xs shadow-sm transition-all flex items-center space-x-2"
        >
          <Send className="w-4 h-4" />
          <span>Submit Access Request</span>
        </button>
      </div>

      {/* Requests List */}
      <div className="space-y-3">
        {relevantRequests.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-2xl border border-[#E5E5E5] shadow-sm">
            <KeyRound className="w-10 h-10 text-neutral-300 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-neutral-800">No Access Requests</h3>
            <p className="text-xs text-neutral-500 mt-1">
              There are currently no pending or resolved access requests in your purview.
            </p>
          </div>
        ) : (
          relevantRequests.map(req => {
            const canReview = isOwner && req.ownerId === currentUser.id && req.status === 'PENDING';

            return (
              <div
                key={req.id}
                className="p-5 rounded-2xl bg-white border border-[#E5E5E5] shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs hover:border-neutral-400 transition-all"
              >
                <div className="space-y-1.5 max-w-xl">
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      req.status === 'PENDING'
                        ? 'bg-amber-50 text-amber-800 border border-amber-200'
                        : req.status === 'APPROVED'
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        : 'bg-rose-50 text-rose-800 border border-rose-200'
                    }`}>
                      {req.status}
                    </span>
                    <span className="font-bold text-neutral-900 text-sm">{req.documentTitle}</span>
                    <span className="px-2 py-0.5 rounded bg-neutral-100 font-mono text-neutral-800 text-[10px] font-bold border border-neutral-200">
                      Requested: {req.requestedLevel}
                    </span>
                  </div>

                  <div className="text-neutral-600 text-[11px]">
                    Requester: <span className="text-neutral-900 font-semibold">{req.requesterName}</span> ({req.requesterEmail}) • {new Date(req.createdAt).toLocaleString()}
                  </div>

                  <div className="p-2.5 rounded-lg bg-[#F8F8F8] border border-neutral-200 text-neutral-800 text-[11px]">
                    <span className="text-neutral-500 font-semibold">Justification: </span>
                    {req.justification}
                  </div>
                </div>

                {/* Owner Decision Actions */}
                <div className="flex items-center space-x-2 shrink-0">
                  {canReview ? (
                    <>
                      <button
                        onClick={() => onApproveRequest(req.id, req.requestedLevel)}
                        className="px-3.5 py-2 rounded-lg bg-[#111111] hover:bg-neutral-800 text-white font-semibold text-xs transition-all flex items-center space-x-1 shadow-sm"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Approve ({req.requestedLevel})</span>
                      </button>

                      <button
                        onClick={() => onRejectRequest(req.id, 'Business justification insufficient.')}
                        className="px-3.5 py-2 rounded-lg bg-white hover:bg-rose-50 border border-rose-300 text-rose-700 font-semibold text-xs transition-all flex items-center space-x-1"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>
                    </>
                  ) : (
                    <div className="text-neutral-500 text-[11px] font-mono font-medium">
                      {req.status === 'PENDING' ? 'Awaiting Owner Review' : `Resolved: ${req.status}`}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* New Request Modal */}
      {showNewRequestModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white border border-[#E5E5E5] rounded-2xl w-full max-w-lg p-6 shadow-2xl space-y-4 text-xs text-neutral-900">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-200">
              <h3 className="text-base font-bold text-neutral-900 flex items-center space-x-2">
                <KeyRound className="w-4 h-4 text-neutral-800" />
                <span>Submit Document Access Request</span>
              </h3>
              <button onClick={() => setShowNewRequestModal(false)} className="text-neutral-400 hover:text-black">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div>
                <label className="text-neutral-700 block mb-1 font-semibold">Select Target Document</label>
                <select
                  value={selectedDocId}
                  onChange={e => setSelectedDocId(e.target.value)}
                  className="w-full bg-[#F8F8F8] border border-neutral-300 rounded-lg p-2.5 text-xs text-neutral-900 focus:outline-none focus:border-black font-medium"
                  required
                >
                  {documents.map(d => (
                    <option key={d.id} value={d.id}>
                      {d.title} (Owner: {d.ownerName})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-neutral-700 block mb-1 font-semibold">Requested Privilege Level</label>
                <select
                  value={requestedLevel}
                  onChange={e => setRequestedLevel(e.target.value as PermissionLevel)}
                  className="w-full bg-[#F8F8F8] border border-neutral-300 rounded-lg p-2.5 text-xs text-neutral-900 focus:outline-none focus:border-black font-medium"
                >
                  <option value="READ">READ (Secure Viewing & Downloading)</option>
                  <option value="EDIT">EDIT (Metadata & Version Modification)</option>
                </select>
              </div>

              <div>
                <label className="text-neutral-700 block mb-1 font-semibold">Business Justification</label>
                <textarea
                  required
                  rows={3}
                  value={justification}
                  onChange={e => setJustification(e.target.value)}
                  placeholder="State the regulatory or operational need for access..."
                  className="w-full bg-[#F8F8F8] border border-neutral-300 rounded-lg p-2.5 text-xs text-neutral-900 focus:outline-none focus:border-black"
                />
              </div>

              <div className="flex items-center justify-end space-x-2 pt-3 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => setShowNewRequestModal(false)}
                  className="px-4 py-2 rounded-lg text-neutral-600 hover:text-black hover:bg-neutral-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#111111] hover:bg-neutral-800 text-white font-semibold rounded-lg shadow-sm"
                >
                  Submit for Owner Approval
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
