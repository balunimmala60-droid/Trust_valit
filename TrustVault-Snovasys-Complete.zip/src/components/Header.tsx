import React, { useState } from 'react';
import { User, NotificationItem, AppTheme } from '../types';
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
  Bell,
  CheckCircle,
  HelpCircle,
  ChevronDown,
  Sun,
  Moon,
  Sparkles,
  Palette
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface HeaderProps {
  currentUser: User;
  allUsers: User[];
  onSwitchUser: (user: User) => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  notifications: NotificationItem[];
  onOpenDemoGuide: () => void;
  chainValid: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  allUsers,
  onSwitchUser,
  activeTab,
  onSelectTab,
  notifications,
  onOpenDemoGuide,
  chainValid
}) => {
  const [showPersonaMenu, setShowPersonaMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showThemeMenu, setShowThemeMenu] = useState(false);

  const { theme, setTheme, toggleTheme, isBW } = useTheme();

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <header className={`sticky top-0 z-40 transition-colors duration-200 border-b shadow-md ${
      isBW
        ? 'bg-[#111111] border-neutral-800 text-white'
        : 'bg-[#0a0f1d]/95 backdrop-blur-md border-slate-800 text-slate-100'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Platform Title */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onSelectTab('dashboard')}>
            <div className={`flex items-center justify-center w-9 h-9 rounded-lg font-black shadow-sm ${
              isBW
                ? 'bg-white text-black'
                : 'bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-cyan-500/20 border border-cyan-400/30'
            }`}>
              <Shield className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-lg font-black tracking-tight text-white">
                  TRUST<span className={isBW ? 'text-neutral-400' : 'text-cyan-400'}>VAULT</span>
                </span>
                <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded border ${
                  isBW
                    ? 'bg-neutral-800 text-neutral-300 border-neutral-700'
                    : 'bg-cyan-950/80 text-cyan-400 border-cyan-800'
                }`}>
                  Zero-Trust
                </span>
              </div>
              <p className={`text-[11px] hidden sm:block ${isBW ? 'text-neutral-400' : 'text-slate-400'}`}>
                Secure Document Sharing & Verifiable Audit Trail
              </p>
            </div>
          </div>

          {/* Center Navigation Tabs */}
          <nav className="hidden lg:flex items-center space-x-1">
            {[
              { id: 'dashboard', label: 'Dashboard' },
              { id: 'documents', label: 'Documents' },
              { id: 'proof-center', label: 'Security Proofs' },
              { id: 'attack-lab', label: 'Attack Replay Lab' },
              { id: 'audit-trail', label: 'Audit Chain' },
              { id: 'copilot', label: 'AI Copilot' },
              { id: 'requests', label: 'Access Requests' },
              ...(currentUser.role === 'ADMIN' ? [{ id: 'admin', label: 'User Admin' }] : []),
              { id: 'theme-settings', label: 'Theme' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                  activeTab === tab.id
                    ? isBW
                      ? 'bg-white text-black shadow-sm'
                      : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/10'
                    : isBW
                    ? 'text-neutral-300 hover:text-white hover:bg-neutral-800/80'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>

          {/* Right Action Tools: Theme Switcher, Judge Demo, Audit Status, Persona Switcher */}
          <div className="flex items-center space-x-2.5">
            {/* Quick Theme Switcher Button */}
            <div className="relative">
              <button
                onClick={() => setShowThemeMenu(!showThemeMenu)}
                className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold border transition-all ${
                  isBW
                    ? 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border-neutral-700'
                    : 'bg-slate-800 hover:bg-slate-700 text-cyan-300 border-slate-700'
                }`}
                title="Switch between Black & White Security and Original Cyber Theme"
              >
                <Palette className="w-3.5 h-3.5" />
                <span className="hidden sm:inline font-mono text-[11px]">
                  {isBW ? 'Theme: B&W' : 'Theme: Original'}
                </span>
                <ChevronDown className="w-3 h-3 opacity-70" />
              </button>

              {showThemeMenu && (
                <div className={`absolute right-0 mt-2 w-56 rounded-xl shadow-2xl p-2 z-50 border text-xs ${
                  isBW
                    ? 'bg-white border-neutral-300 text-neutral-900'
                    : 'bg-slate-900 border-slate-700 text-slate-100'
                }`}>
                  <div className={`px-2 py-1 text-[10px] font-bold uppercase tracking-wider border-b mb-1 ${
                    isBW ? 'text-neutral-500 border-neutral-100' : 'text-slate-400 border-slate-800'
                  }`}>
                    Display Theme Settings
                  </div>

                  <button
                    onClick={() => {
                      setTheme('bw');
                      setShowThemeMenu(false);
                    }}
                    className={`w-full text-left p-2 rounded-lg flex items-center justify-between transition-all ${
                      theme === 'bw'
                        ? isBW
                          ? 'bg-neutral-100 text-black font-bold border border-neutral-300'
                          : 'bg-slate-800 text-white font-bold'
                        : isBW
                        ? 'hover:bg-neutral-50 text-neutral-800'
                        : 'hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 rounded-full bg-black border border-white" />
                      <div>
                        <div className="font-semibold">Black & White Security</div>
                        <div className={`text-[10px] ${isBW ? 'text-neutral-500' : 'text-slate-400'}`}>High-contrast minimalist</div>
                      </div>
                    </div>
                    {theme === 'bw' && <CheckCircle className="w-3.5 h-3.5 text-black" />}
                  </button>

                  <button
                    onClick={() => {
                      setTheme('original');
                      setShowThemeMenu(false);
                    }}
                    className={`w-full text-left p-2 rounded-lg flex items-center justify-between transition-all mt-1 ${
                      theme === 'original'
                        ? isBW
                          ? 'bg-neutral-100 text-black font-bold border border-neutral-300'
                          : 'bg-cyan-950/80 text-cyan-300 font-bold border border-cyan-800'
                        : isBW
                        ? 'hover:bg-neutral-50 text-neutral-800'
                        : 'hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 rounded-full bg-cyan-400 border border-slate-900" />
                      <div>
                        <div className="font-semibold">Original TrustVault</div>
                        <div className={`text-[10px] ${isBW ? 'text-neutral-500' : 'text-slate-400'}`}>Deep navy & electric cyan</div>
                      </div>
                    </div>
                    {theme === 'original' && <CheckCircle className="w-3.5 h-3.5 text-cyan-400" />}
                  </button>
                </div>
              )}
            </div>

            {/* Judge 5-Minute Evaluation Guide */}
            <button
              onClick={onOpenDemoGuide}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-bold transition-all shadow-sm ${
                isBW
                  ? 'bg-white text-black hover:bg-neutral-200'
                  : 'bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
              }`}
              title="Open 5-Minute Evaluator Script"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">5-Min Demo</span>
            </button>

            {/* Audit Chain Status Indicator */}
            <div
              onClick={() => onSelectTab('audit-trail')}
              className={`cursor-pointer flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs font-mono font-medium border ${
                chainValid
                  ? isBW
                    ? 'bg-neutral-900 text-emerald-400 border-neutral-700 hover:bg-neutral-800'
                    : 'bg-emerald-950/50 text-emerald-400 border-emerald-800/60 hover:bg-emerald-900/40'
                  : 'bg-rose-950 text-rose-300 border-rose-800 animate-pulse'
              }`}
              title="SHA-256 Merkle Chain Integrity"
            >
              <span className={`w-2 h-2 rounded-full ${chainValid ? 'bg-emerald-400' : 'bg-rose-400'}`} />
              <span className="hidden md:inline">{chainValid ? 'Audit: OK' : 'Tampered!'}</span>
            </div>

            {/* Notifications Menu */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className={`relative p-2 rounded-md transition-all ${
                  isBW
                    ? 'text-neutral-300 hover:text-white hover:bg-neutral-800'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
                title="Notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className={`absolute top-1 right-1 w-2 h-2 rounded-full ${isBW ? 'bg-white' : 'bg-cyan-400 animate-ping'}`} />
                )}
              </button>

              {showNotifications && (
                <div className={`absolute right-0 mt-2 w-80 rounded-xl shadow-2xl p-3 z-50 border ${
                  isBW
                    ? 'bg-white border-neutral-200 text-neutral-900'
                    : 'bg-slate-900 border-slate-700 text-slate-100'
                }`}>
                  <div className={`flex items-center justify-between pb-2 border-b ${
                    isBW ? 'border-neutral-200' : 'border-slate-800'
                  }`}>
                    <span className="text-xs font-bold uppercase tracking-wider">Security Notifications</span>
                    <span className={`text-[10px] font-mono ${isBW ? 'text-neutral-500' : 'text-slate-400'}`}>{notifications.length} events</span>
                  </div>
                  <div className={`max-h-60 overflow-y-auto divide-y mt-1 ${isBW ? 'divide-neutral-100' : 'divide-slate-800/50'}`}>
                    {notifications.map(n => (
                      <div key={n.id} className="py-2 text-xs">
                        <div className={`font-semibold ${isBW ? 'text-neutral-900' : 'text-slate-200'}`}>{n.title}</div>
                        <div className={`text-[11px] mt-0.5 ${isBW ? 'text-neutral-600' : 'text-slate-400'}`}>{n.message}</div>
                        <div className={`text-[9px] mt-1 font-mono ${isBW ? 'text-neutral-400' : 'text-slate-500'}`}>{new Date(n.createdAt).toLocaleTimeString()}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Quick Demo Persona Switcher */}
            <div className="relative">
              <button
                onClick={() => setShowPersonaMenu(!showPersonaMenu)}
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-md border text-xs font-medium transition-all ${
                  isBW
                    ? 'border-neutral-700 bg-neutral-900 hover:bg-neutral-800 text-white'
                    : 'bg-slate-900/80 hover:bg-slate-800 border-slate-700 text-slate-200'
                }`}
              >
                <UserCheck className={`w-3.5 h-3.5 ${isBW ? 'text-neutral-300' : 'text-cyan-400'}`} />
                <div className="text-left">
                  <div className="font-bold leading-none">{currentUser.fullName.split(' ')[0]}</div>
                  <div className={`text-[9px] leading-tight uppercase font-mono ${isBW ? 'text-neutral-400' : 'text-slate-400'}`}>{currentUser.role}</div>
                </div>
                <ChevronDown className="w-3 h-3 opacity-70" />
              </button>

              {showPersonaMenu && (
                <div className={`absolute right-0 mt-2 w-72 rounded-xl shadow-2xl p-2 z-50 border ${
                  isBW
                    ? 'bg-white border-neutral-300 text-neutral-900'
                    : 'bg-slate-900 border-slate-700 text-slate-100'
                }`}>
                  <div className={`px-2 py-1.5 text-[10px] font-bold uppercase tracking-wider border-b mb-1 ${
                    isBW ? 'text-neutral-500 border-neutral-100' : 'text-slate-400 border-slate-800'
                  }`}>
                    Judge Quick-Switch Persona
                  </div>
                  <div className={`text-[10px] px-2 mb-2 ${isBW ? 'text-neutral-600' : 'text-slate-400'}`}>
                    Test permissions instantly without logging out:
                  </div>
                  <div className="space-y-1">
                    {allUsers.map(user => (
                      <button
                        key={user.id}
                        onClick={() => {
                          onSwitchUser(user);
                          setShowPersonaMenu(false);
                        }}
                        className={`w-full text-left p-2 rounded-lg text-xs transition-all flex items-center justify-between ${
                          currentUser.id === user.id
                            ? isBW
                              ? 'bg-neutral-100 text-neutral-900 font-bold border border-neutral-300'
                              : 'bg-cyan-950/80 text-cyan-300 border border-cyan-800'
                            : isBW
                            ? 'hover:bg-neutral-50 text-neutral-800'
                            : 'hover:bg-slate-800 text-slate-300'
                        }`}
                      >
                        <div>
                          <div className={`font-semibold ${isBW ? 'text-neutral-900' : 'text-white'}`}>{user.fullName}</div>
                          <div className={`text-[10px] font-mono ${isBW ? 'text-neutral-500' : 'text-slate-400'}`}>{user.email}</div>
                        </div>
                        <span className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold ${
                          isBW
                            ? 'bg-neutral-900 text-white'
                            : 'bg-slate-800 text-cyan-300 border border-slate-700'
                        }`}>
                          {user.role}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Navigation bar */}
      <div className={`lg:hidden flex items-center space-x-1.5 overflow-x-auto px-4 py-2 border-t ${
        isBW ? 'border-neutral-800 bg-[#111111]' : 'border-slate-800 bg-slate-950/80'
      }`}>
        {[
          { id: 'dashboard', label: 'Dashboard' },
          { id: 'documents', label: 'Docs' },
          { id: 'proof-center', label: 'Proofs' },
          { id: 'attack-lab', label: 'Attacks' },
          { id: 'audit-trail', label: 'Audit' },
          { id: 'copilot', label: 'Copilot' },
          { id: 'requests', label: 'Requests' },
          { id: 'theme-settings', label: 'Theme' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => onSelectTab(tab.id)}
            className={`whitespace-nowrap px-2.5 py-1 rounded text-xs font-semibold ${
              activeTab === tab.id
                ? isBW
                  ? 'bg-white text-black'
                  : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : isBW
                ? 'text-neutral-400'
                : 'text-slate-400'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </header>
  );
};
