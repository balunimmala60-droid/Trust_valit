import React, { useState } from 'react';
import { User } from '../types';
import {
  HelpCircle,
  X,
  ArrowRight
} from 'lucide-react';

interface JudgeDemoModalProps {
  onClose: () => void;
  allUsers: User[];
  onSwitchUser: (user: User) => void;
  onSelectTab: (tab: string) => void;
}

export const JudgeDemoModal: React.FC<JudgeDemoModalProps> = ({
  onClose,
  allUsers,
  onSwitchUser,
  onSelectTab
}) => {
  const [currentStep, setCurrentStep] = useState(1);

  const owner = allUsers.find(u => u.role === 'OWNER') || allUsers[0];
  const viewerDavid = allUsers.find(u => u.id === 'user_viewer_01') || allUsers[0];
  const admin = allUsers.find(u => u.role === 'ADMIN') || allUsers[0];

  const steps = [
    {
      minute: 'Minute 1',
      title: 'Platform Architecture & Owner Context',
      description: 'Explain TrustVault: Zero-Trust Document Sharing with a Cryptographic Audit Trail. Begin logged in as Sarah Chen (Owner). Explore the real-time access radar and live system metrics.',
      actionLabel: 'Switch to Sarah Chen (Owner) & Open Dashboard',
      action: () => {
        onSwitchUser(owner);
        onSelectTab('dashboard');
        onClose();
      }
    },
    {
      minute: 'Minute 2',
      title: 'Document Integrity & Granular Delegation',
      description: 'Navigate to Document Library. Open the Security Passport for "Series B Financial Cap Table". Observe the SHA-256 checksum and isolated storage UUID. Grant READ permission to David Ross (Viewer) with optional expiration.',
      actionLabel: 'Open Documents as Sarah (Owner)',
      action: () => {
        onSwitchUser(owner);
        onSelectTab('documents');
        onClose();
      }
    },
    {
      minute: 'Minute 3',
      title: 'Viewer Access & IDOR Defense Demonstration',
      description: 'Switch persona to David Ross (Viewer). Demonstrate that David can securely preview and download the authorized Cap Table. Then observe that unshared documents are strictly denied (HTTP 403 Forbidden).',
      actionLabel: 'Switch to David Ross (Viewer)',
      action: () => {
        onSwitchUser(viewerDavid);
        onSelectTab('documents');
        onClose();
      }
    },
    {
      minute: 'Minute 4',
      title: 'Immediate Server Revocation (0ms Window)',
      description: 'Switch back to Sarah Chen (Owner) and revoke David\'s access. Switch immediately back to David and attempt download: observe instant 403 denial with zero cached grace period! Inspect the audit log showing the revocation event.',
      actionLabel: 'Switch to Sarah to Revoke / David to Verify',
      action: () => {
        onSwitchUser(owner);
        onSelectTab('documents');
        onClose();
      }
    },
    {
      minute: 'Minute 5',
      title: 'Cryptographic Audit Proof & Attack Replay Lab',
      description: 'Open the Audit Chain view: click "Verify Hash Chain Integrity" to validate every SHA-256 link. Click "Simulate Tampering" to watch the engine immediately catch an altered byte! Finally, open the Attack Replay Lab to run live IDOR and privilege escalation attacks.',
      actionLabel: 'Open Security Proof Center & Attack Lab',
      action: () => {
        onSwitchUser(admin);
        onSelectTab('proof-center');
        onClose();
      }
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white border border-[#E5E5E5] rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-[#E5E5E5] flex items-center justify-between bg-[#F8F8F8]">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-black text-white flex items-center justify-center shadow-sm">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-[10px] uppercase font-bold text-neutral-600 tracking-wider">
                  Hackathon Evaluation Script
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">5 Minutes • 100 Marks Benchmark</span>
              </div>
              <h2 className="text-base font-black text-neutral-900 tracking-tight">
                TrustVault Evaluator Walkthrough Guide
              </h2>
            </div>
          </div>

          <button onClick={onClose} className="p-2 rounded-lg text-neutral-400 hover:text-black hover:bg-neutral-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Navigation */}
        <div className="flex items-center justify-between px-6 pt-4 border-b border-[#E5E5E5] bg-[#F8F8F8]/50 text-xs">
          {steps.map((s, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentStep(idx + 1)}
              className={`pb-3 font-bold transition-all border-b-2 flex items-center space-x-1 ${
                currentStep === idx + 1
                  ? 'border-black text-black'
                  : 'border-transparent text-neutral-400 hover:text-neutral-800'
              }`}
            >
              <span>{s.minute}</span>
            </button>
          ))}
        </div>

        {/* Current Step Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs flex-1 bg-white text-neutral-900">
          {(() => {
            const step = steps[currentStep - 1];
            return (
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <span className="px-2.5 py-1 rounded bg-black text-white font-bold font-mono text-[10px]">
                    {step.minute}
                  </span>
                  <h3 className="text-base font-black text-neutral-900">{step.title}</h3>
                </div>

                <div className="p-4 rounded-xl bg-[#F8F8F8] border border-[#E5E5E5] text-neutral-700 leading-relaxed text-xs">
                  {step.description}
                </div>

                <div className="p-4 rounded-xl bg-neutral-50 border border-neutral-300 space-y-2">
                  <span className="text-[10px] font-bold text-neutral-600 uppercase tracking-wider block">
                    Recommended Judge Action for this Minute:
                  </span>
                  <button
                    onClick={step.action}
                    className="w-full py-2.5 px-4 rounded-lg bg-[#111111] hover:bg-neutral-800 text-white font-bold text-xs shadow-sm transition-all flex items-center justify-center space-x-2"
                  >
                    <span>{step.actionLabel}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })()}
        </div>

        {/* Footer Navigation */}
        <div className="p-4 border-t border-[#E5E5E5] bg-[#F8F8F8] flex items-center justify-between text-xs">
          <button
            onClick={() => setCurrentStep(prev => Math.max(1, prev - 1))}
            disabled={currentStep === 1}
            className="px-3 py-1.5 rounded-lg text-neutral-500 hover:text-black disabled:opacity-30 font-semibold"
          >
            Previous Minute
          </button>

          <span className="text-neutral-500 text-[11px] font-mono">
            Step {currentStep} of {steps.length}
          </span>

          <button
            onClick={() => setCurrentStep(prev => Math.min(steps.length, prev + 1))}
            disabled={currentStep === steps.length}
            className="px-3 py-1.5 rounded-lg text-black hover:underline disabled:opacity-30 font-bold"
          >
            Next Minute
          </button>
        </div>
      </div>
    </div>
  );
};
